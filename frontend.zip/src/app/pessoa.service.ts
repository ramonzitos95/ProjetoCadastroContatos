import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Pessoa } from './model/pessoa-model';

@Injectable({
  providedIn: 'root'
})
export class PessoaService  {
  private apiUrl = 'http://localhost:5256/api/Pessoa/'; // Substitua pela URL da sua API

 
  constructor(private http: HttpClient) {}

  getAllPessoas(): Observable<Pessoa[]> {
    return this.http.get<Pessoa[]>(this.apiUrl);
  }

  getPessoaById(id: number): Observable<Pessoa> {
    return this.http.get<Pessoa>(`${this.apiUrl}/${id}`);
  }

  addPessoa(pessoa: Pessoa): Observable<Pessoa> {
    console.log(pessoa);
    console.log(this.apiUrl);

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.http.post<Pessoa>(this.apiUrl, pessoa, httpOptions);
  }

  updatePessoa(pessoa: Pessoa): Observable<Pessoa> {
    return this.http.put<Pessoa>(`${this.apiUrl}/${pessoa.Id}`, pessoa);
  }

  deletePessoa(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}