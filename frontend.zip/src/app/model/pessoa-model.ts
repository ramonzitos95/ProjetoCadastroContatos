export interface Pessoa {
    Id: number;
    Nome: string;
    Idade: number;
    Contatos: Contato[];
}

export interface Contato {
    Id: number;
    Type: string;
    Value: string;
}