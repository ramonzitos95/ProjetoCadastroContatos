import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { PessoaService } from '../pessoa.service';

@Component({
  selector: 'app-contato-modal',
  templateUrl: './contato-modal.component.html',
  styleUrls: ['./contato-modal.component.css']
})
export class ContatoModalComponent implements OnInit {

  public cadastroForm2: FormGroup;

  constructor(public activeModal: NgbActiveModal,
    private formBuilder: FormBuilder,
    private PessoaService: PessoaService) {
      this.cadastroForm2 = this.formBuilder.group({
        Nome: ['', Validators.required],
        Idade: ['', [Validators.required, Validators.min(0)]],
        Contatos: this.formBuilder.array([])
      });
  }

  ngOnInit() {
    this.cadastroForm2 = this.formBuilder.group({
      Nome: ['', Validators.required],
      Idade: ['', [Validators.required, Validators.min(0)]],
      Contatos: this.formBuilder.array([])
    });
  }

  get contatos(): FormArray {
    return this.cadastroForm2.get('Contatos') as FormArray;
  }

  adicionarContato() {
    const contatoGroup = this.formBuilder.group({
      Type: ['', Validators.required],
      Value: ['', Validators.required]
    });

    this.contatos.push(contatoGroup);
  }

  removerContato(index: number) {
    this.contatos.removeAt(index);
  }

  onSubmit() {
    if (this.cadastroForm2.valid) {
      var pessoa = this.cadastroForm2.value;
      console.log(pessoa);
      this.PessoaService.addPessoa(pessoa);
    }
  }

  // save() {
  //   // Lógica para salvar o contato
  //   this.activeModal.close('Contact saved');
  // }

  // cancel() {
  //   this.activeModal.dismiss('Canceled');
  // }
}