import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ContatoModalComponent } from '../contato-modal/contato-modal.component';

@Component({
  selector: 'app-pessoa',
  templateUrl: './pessoa.component.html',
  styleUrls: ['./pessoa.component.css']
})
export class PessoaComponent {

  constructor(private modalService: NgbModal) { }

  openContatoModal() {
    const modalRef = this.modalService.open(ContatoModalComponent);
  }
}